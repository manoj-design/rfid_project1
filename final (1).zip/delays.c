//delay function for micro seconds
#include "typedef.h"
void delay_us(u32 dlyus)
{
	dlyus*=12;
	while(dlyus--);
}
//delay function for milli seconds
void delay_ms(u32 dlyms)
{
	dlyms*=12000;
	while(dlyms--);
}
//delay function for seconds
void delay_s(u32 dlys)
{
	dlys*=12000000;
	while(dlys--);
}
