#include<LPC21xx.h>
#include "delay.h"
#include "typedef.h"
#include "LCD.h"
#include "SPI.h"
#include "RTC.h"
#include <string.h>

#include<LPC21xx.h>
#include "delay.h"
#include "typedef.h"
#include "LCD.h"
#include "SPI.h"
#include "RTC.h"
#include <string.h>

//defines for clock
#define FOSC 12000000
#define CCLK (FOSC*5)
#define PCLK (CCLK/4)
#define BAUD 9600
#define DIVISOR (PCLK/(16*BAUD))
//defines for I2c

//defines for LCR
#define _8bits 3
#define WORD_LEN _8bits
#define DLAB 7
//defines for LSR
#define DR 0
#define THRE_BIT 5
#define TEMT_BIT 6
//defines for Uart0 interrupt
#define UART_INT 7
#define RBR_INT 0
#define THR_INT 1

//defines for UART int
#define UART_INT_CHNO 7
//defines for clock
#define FOSC 12000000
#define CCLK (FOSC*5)
#define PCLK (CCLK/4)
#define BAUD 9600
#define DIVISOR (PCLK/(16*BAUD))
//defines for I2c

//defines for LCR
#define _8bits 3
#define WORD_LEN _8bits
#define DLAB 7
//defines for LSR
#define DR 0
#define THRE_BIT 5
#define TEMT_BIT 6
//defines for Uart1 interrupt
#define UART0_INT 7
#define RBR_INT 0
#define THR_INT 1

//defines for UART int
#define UART_INT_CHNO 7
#define TIMECOUNT 10000000
extern s8 admin[15];
s8 ch[20],flag=0,uart=0,check=0;
s32 j,t,cnt,tcount=0;

void InitUART(void)
{
        PINSEL0|=0x00051505;
	//UART 2
	      U0LCR=1<<DLAB|WORD_LEN;
        U0DLM=0x00;
        U0DLL=0x61;
        U0LCR&=~(1<<DLAB);
	//UART 1
        U1LCR=1<<DLAB|WORD_LEN;
        U1DLM=0x00;
        U1DLL=0x61;
        U1LCR&=~(1<<DLAB);
	
}
//UART 0 functions
void U0_Tx_Char(u8 byte)
{
        U0THR=byte;
        while(((U0LSR>>TEMT_BIT)&1)==0);
}
u8 U0_Rx_Char(void)
{
        while(((U0LSR>>DR)&1)==0);
        return U0RBR;
}

void U0_Tx_Str(s8 *s)
{
        while(*s)
                U0_Tx_Char(*s++);
}
void U0_Rx_Str(char *p)
{
	s8 i=0,k;
	while(1)
	{
		k=U0_Rx_Char();
		if(k=='$')
		{
			break;
		}
		else
		{
			p[i++]=k;
		}
	
	}
	p[i]='\0';

}
//UART 1 Functions
void U1_Tx_Char(u8 byte)
{
        U1THR=byte;
        while(((U1LSR>>TEMT_BIT)&1)==0);
}
s8 U1_Rx_Char(void)
{
        while(((U1LSR>>DR)&1)==0);
        return U1RBR;
}

void U1_Tx_Str(s8 *s)
{
        while(*s)
                U1_Tx_Char(*s++);
}
void U1_Rx_Str(char *c)
{
	s8 i=0,k;
	while(1)
	{
		k=U1_Rx_Char();
		if(k!=0x03 && k!=0x02)
		{
			c[i++]=k;
		if(i==8)
			break;
	}
	}
	c[i]='\0';
} 
void UART_ISR(void) __irq
{
s8 r,a[30]="A",u[30]="U",t[2]="$";
        r=U1RBR;
		U1_Tx_Char(r);
        /*if(r==0x02)
        {
               flag=1;
        }
		else if(r!=0x03 && flag==1)
		{
			ch[j++]=r;
		}
		else if(r==0x03)
		{
			flag=0;
			j=0;
		}*/
		if(r!=0x02 && r!=0x03)
		{
			ch[j++]=r;
		}
        if(j==8)
        {
                ch[j]='\0';
                U1_Tx_Str(ch);
                U1_Tx_Str("\r\n");
				//U0_Tx_Str(ch);
                flag=0;
                j=0;
					 if(strcmp(admin,ch)==0)
    {
		cmdLCD(0x01);
		cmdLCD(0x80);
		strLCD("ADMIN ACCESS");
	    strcat(a,ch);
		strcat(a,t);
	    U0_Tx_Str(a);
		r=U0_Rx_Char();
		cmdLCD(0x01);
    }
    else
    {
	  strcat(u,ch);
	  strcat(u," ");
	  strcat(u,Get_Time());
						//strcat(u," ");
						//strcat(u,Get_Date());
						strcat(u,t);
						U0_Tx_Str(u);
						cmdLCD(0x01);
						cmdLCD(0x80);
						strLCD("Processing..");
						while(tcount<TIMECOUNT)
						{
							if(U0LSR&0x01)
							{
								r=U0_Rx_Char();
								check=1;
								break;
							}
							tcount++;
						}
						if(check)
						{
							check=0;
							tcount=0;
							if(r=='1')
						{
							cmdLCD(0x01);
							cmdLCD(0x82);
							strLCD("Attendance");
							cmdLCD(0xc3);
							strLCD("Updated");
							delay_ms(1000);
							cmdLCD(0x01);
						}
						else if(r=='2')
						{
							cmdLCD(0x01);
							cmdLCD(0x84);
							strLCD("Entries");
							cmdLCD(0xc3);
							strLCD("Exceeded");
							delay_ms(1000);
							cmdLCD(0x01);
						}
						else if(r=='3')
						{
							cmdLCD(0x01);
							cmdLCD(0x80);
							strLCD("Invalid Card");
							delay_ms(1000);
							cmdLCD(0x01);
						}
					}
						 else
					{
						tcount=0;
						cmdLCD(0x01);
						cmdLCD(0x84);
						strLCD("Server");
						cmdLCD(0xc2);
						strLCD("Unavailable");
						delay_ms(1000);
						cmdLCD(0x01);
					}
					}
	 		 
					uart=1;
        }
        U1IIR=0;
        VICVectAddr=0;

}
void ENABLE_UART_INT(void)
{
        U1IER=(1<<RBR_INT)|(1<<3);
        //ENABLING FIFO AND Rx TRIGGER LEVEL
        VICIntEnable=1<<UART_INT_CHNO;
        VICVectCntl0=(1<<5)|UART_INT_CHNO;
        VICVectAddr0=(u32)UART_ISR;
}
void DISABLE_UART_INT(void)
{
	U1IER=0x00;
	VICIntEnClr=1<<UART_INT_CHNO;
}
