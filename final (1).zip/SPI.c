//spi_eeprom_test.c
#include <LPC21xx.h>
#include "typedef.h"
#include "delay.h"
#include "LCD.h"
//define pin functions  
#define SCK  4 //p0.4 
#define MISO 5 //p0.5 
#define MOSI 6 //p0.6
#define _SS  7 //p0.7  
#define DIVISOR   8

//bit defines for SPCR sfr
#define   BIT_EN_BIT 2
#define   CPHA_BIT   3
#define   CPOL_BIT   4
#define   MSTR_BIT   5
#define   LSBF_BIT   6

//bit defines for SPSR sfr
#define   SPIF_BIT   7

//defines for 25LC512 spi eeprom commands
#define WREN 0x06
#define WRDI 0x04
#define WRITE 0x02
#define READ 0x03

void Init_SPI(void)
{
   //Cfg p0.4,P0.5,P0.6 for SCK,MOSI,MISO functions 
	 //using PINSEL0
	 PINSEL0|=0x00051505;
	 //cfg mode=3,serial order msb first def
	 S0SPCR=((1<<MSTR_BIT)|(1<<CPHA_BIT)|(1<<CPOL_BIT));
   //Cfg Speed for SPI Serial Communication
   S0SPCCR=DIVISOR; 
	 //initialize chip select
	 IOSET0  = 1 << _SS;
   IODIR0 |= 1 << _SS;	
}

u8 spi(u8 sByte)
{
	 S0SPDR=sByte;
	 while(((S0SPSR>>SPIF_BIT)&1)==0);
	 return S0SPDR;
}

void WriteEnable(void)
{
	IOCLR0=1 << _SS;
	spi(WREN);
	IOSET0= 1<< _SS;
}

void WriteDisable(void)
{
	IOCLR0= 1 << _SS;
	spi(WRDI);
	IOSET0= 1 << _SS;
}

unsigned char spi_Read(void) {
    S0SPDR = 0xFF;
    while (!(S0SPSR & 0x80));
    return S0SPDR;
}
void spi_eeprom_bytewrite(u16 wBuffAddr,u8 wByte)
{
	WriteEnable();
	IOCLR0=1 << _SS;
	spi(WRITE);
	spi(wBuffAddr>>8);
	spi(wBuffAddr);
	spi(wByte);
 	IOSET0= 1 << _SS;
	delay_ms(10);
	WriteDisable();	
}
u8 spi_eeprom_byteread(u16 rBuffAddr)                      
{
	u8 rByte;
	IOCLR0=1 << _SS;
	spi(READ);
	spi(rBuffAddr>>8);
	spi(rBuffAddr);
	rByte=spi(0x00);
 	IOSET0= 1 << _SS;
	return rByte;
}
void spi_eeprom_pagewrite(u16 wBuffAddr,s8 *p,s8 n)
{
	s8 i;
	/*WriteEnable();
	IOCLR0=1<<_SS;
	spi(WRITE);
	spi(wBuffAddr>>8);
	spi(wBuffAddr);
	while(*p)
		spi(*p++);
//	spi('\0');	   */
	for(i=0;i<n;i++)
	{
	 spi_eeprom_bytewrite(wBuffAddr+i,p[i]);
	}

/*	IOSET0= 1 << _SS;
	delay_ms(10);
	WriteDisable();	  */
}
void spi_eeprom_sequentialread(u16 rBuffAddr,s8 *p,int nbytes)
{
	u8 i;

	for(i=0;i<nbytes;i++)
	{
	p[i]=spi_eeprom_byteread(rBuffAddr+i);
	}
	p[i]='\0';
}

