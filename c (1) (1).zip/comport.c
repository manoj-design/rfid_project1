#include<stdio.h>
#include<termios.h>
#include<sys/types.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
int fd;
void Init_comport(void)
{
	
	fd=open("/dev/ttyUSB0",O_RDWR);
	if(fd<0)
	{
		perror("open");
		exit(0);
	}
	struct termios n;
	tcgetattr(fd,&n);
	cfmakeraw(&n);
	cfsetispeed(&n,9600);
	cfsetospeed(&n,9600);

	n.c_cflag |=(CLOCAL|CREAD);
	n.c_cflag|=CS8;
	n.c_cflag&=~(CSTOPB);
	n.c_cflag&=~(PARENB);

	n.c_lflag &=~(ICANON | ECHO | ECHOE |ISIG);
	n.c_oflag&=~OPOST;
	tcsetattr(fd,TCSANOW|TCSAFLUSH,&n);
	usleep(1000);
}
char *readfromcomport(void)
{
	tcflush(fd,TCIFLUSH);
	int ret;
	static char r[100];
	static char *p;
	char c=0,j=0;	
	while(c != '$'){
		ret= read(fd,&c,1);
		r[j++]=c;
	}
	r[j]='\0';
	puts(r);
	p=r;
	if(ret==-1)
	{
		perror("read");
		exit(0);
	}
	return p;
}
void writetocomport(char p)
{
	int ret;
	ret=write(fd,&p,1);
	if(ret==-1)
	{
		perror("write");
		exit(0);
	}
}
void u32_writetocomport(int n)
{
	char c[10],i=0;
	while(n)
	{
		c[i++]=n%10+48;
		n/=10;
	}
	for(i--;i>=0;i--)
	{
		writetocomport(c[i]);
	}

}
void str_writetocomport(char *p)
{
	while(*p)
	{
		writetocomport(*p++);
	}
}

