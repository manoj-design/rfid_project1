#include "headers.h"
void get_sys_time(char *ltime)
{
	time_t time1;
	struct tm *timeinfo;
	time(&time1);
	timeinfo=localtime(&time1);
	strftime(ltime,20,"%d-%m-%Y %H:%M:%S",timeinfo);
}
void check_date_change(void)
{
	FILE *fp;
	fp=fopen("date.txt","r+");
	char ch[20],buff[30],*p;
	fgets(ch,20,fp);
	int size=ftell(fp);
	ch[strlen(ch)-1]='\0';
	get_sys_time(buff);
	p=strtok(buff," ");
	if(strcmp(ch,buff)!=0)
	{
		fseek(fp,-size,1);
		fputs(buff,fp);
		create_file(buff);
	}
	fclose(fp);
}
	


