#include<stdio.h>
#include<termios.h>
#include<sys/types.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
char *readfromcomport(void);
void Init_comport(void);
void writetocomport(char);

