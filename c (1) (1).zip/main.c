#include "headers.h"
int i=0,pcount;
int main()
{

	char *p,*q,s[30];
	//char p[30],*q;
	STU *sp;
	Init_comport();
	memset(s,'\0',30);
	get_sys_time(s);
	q=strtok(s," ");
	check_date_change();
	sp=readfromfile(s);
	printfile(sp,1);
	pcount=get_present_count();
	while(1)
	{
		p=NULL;
		p=readfromcomport();
		//scanf("%s",p);
		printf("%s\n",p);
		if(p[0]=='A')
		{
			adminmenu();
			writetocomport('1');
		}
		else if(p[0]=='U')
		{
			sp=user(p+1,sp);	
			writetofile(sp);
			printfile(sp,1);
			write_present_count(pcount);
		}
		else if(p[0]=='D')
		{
			memset(s,'\0',30);
			get_sys_time(s);
			strcat(s,"$");
			printf("%s\n",s);
			str_writetocomport(s);
		}
		else if(p[0]=='P')
		{
			int n;
			n=get_present_count();
			u32_writetocomport(n);
		}
		check_date_change();
	}
}
		

