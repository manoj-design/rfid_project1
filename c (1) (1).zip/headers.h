
#include<stdio.h>
#include<stdio_ext.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include "comport.h"
typedef struct STUDENT
{
	char id[10];
	char name[20];
	char status[5];
	char date[15];
	int count;
	char itime1[15];
	char otime1[15];
	char itime2[15];
	char otime2[15];
	char itime3[15];
	char otime3[15];
	char workinghrs[15];
}STU;
STU *readfromfile();
void writetofile(STU *);
void printfile(STU *,int);
int checkid(STU*,char*,int);
void adminmenu(void);
STU *user(char *,STU *);
void get_sys_time(char *);
int get_present_count(void);
void write_present_count(int);
void check_date_change();
void create_file(char *p);
void u32_writetocomport(int );
void str_writetocomport(char *);
