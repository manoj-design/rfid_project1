#include "headers.h"
extern int i;
extern int mi;
char file[30];
STU *readfromfile(char *filename)
{
	char date[15];
	STU *sp=NULL;
	FILE *fp;
	strcpy(date,filename);
	strcat(filename,".csv");
	fp=fopen(filename,"r");
	strcpy(file,filename);
	if(fp==NULL)
	{
		printf("File not Exists\n");
		exit(0);
	}
	char ch[256],cnt=0;	
	fgets(ch,256,fp);//for reading header file
	memset(ch,'\0',256);
	while(fgets(ch,256,fp))
	{
		if(strcmp(ch,"\n")==0)
			break;
		sp=realloc(sp,(i+1)*sizeof(STU));
		char *p=ch;
		p=strtok(p,",");
		strcpy(sp[i].id,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[i].name,p);
		p=NULL;
                p=strtok(p,",");
                strcpy(sp[i].date,date);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[i].status,p);	
		p=NULL;
		p=strtok(p,",");
		sp[i].count=atoi(p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[i].itime1,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[i].otime1,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[i].itime2,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[i].otime2,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[i].itime3,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[i].otime3,p);
		p=NULL;
		p=strtok(p,",");
		strncpy(sp[i].workinghrs,p,strlen(p)-1);
		i++;
		memset(ch,'\0',256);
	}
	fclose(fp);
	return sp;
}
void writetofile(STU *p)
{
	FILE *fp;
	fp=fopen(file,"r+");
	char ch[256],c[3];
	fgets(ch,256,fp);
	memset(ch,'\0',256);
	for(int j=0;j<i;j++)
	{
		strcat(ch,p[j].id);
		strcat(ch,",");
		strcat(ch,p[j].name);
		strcat(ch,",");
		strcat(ch,p[j].date);
		strcat(ch,",");
		strcat(ch,p[j].status);
		strcat(ch,",");
		c[0]=p[j].count+48;
		c[1]='\0';
		strcat(ch,c);
		strcat(ch,",");
		strcat(ch,p[j].itime1);
		strcat(ch,",");
		strcat(ch,p[j].otime1);
		strcat(ch,",");
		strcat(ch,p[j].itime2);
		strcat(ch,",");
		strcat(ch,p[j].otime2);
		strcat(ch,",");
		strcat(ch,p[j].itime3);
		strcat(ch,",");
		strcat(ch,p[j].otime3);
		strcat(ch,",");
		strcat(ch,p[j].workinghrs);
		strcat(ch,"\n");
		fputs(ch,fp);
		memset(ch,'\0',256);
	}
	fclose(fp);
}
		
int checkid(STU *p,char *ch,int n)
{

	if(n==1)
	{
		n=i;
	}
	else if(n==2)
	{
		n=mi;
	}

	for(int j=0;j<n;j++)
	{
		if(strcmp(p[j].id,ch)==0)
		{
			return j;
		}
	}
	return -1;
}
int get_present_count(void)
{

	FILE *fp;
	char ch[10];
	fp=fopen("count.txt","r");
	fgets(ch,10,fp);
	return (atoi(ch));
}
void write_present_count(int n)
{
	FILE *fp;
	char ch[10];
	fp=fopen("count.txt","w");
	fputc(n,fp);
}
void create_file(char *p)
{
	FILE *fp,*fp1;
	fp=fopen("mastercopy.csv","r");
	if(fp==NULL)
	{
		printf("master copy not exits\n");
		exit(0);
	}
	strcat(p,".csv");
	fp1=fopen(p,"w");
	char ch[256];
	while(fgets(ch,256,fp))
	{
		fputs(ch,fp1);
	}
	fclose(fp);
	fclose(fp1);
}

void printfile(STU *p,int n)
{
	printf("Total Present:%d\n",get_present_count());
	if(n==1)
	{
		n=i;
	}
	else if(n==2)
	{
		n=mi;
	}

	for(int j=0;j<n;j++)
	{
		printf("%s ",p[j].id);
		printf("%s ",p[j].name);
		printf("%s ",p[j].date);
		printf("%s ",p[j].status);
		printf("%d ",p[j].count);
		printf("%s ",p[j].itime1);
		printf("%s ",p[j].otime1);
		printf("%s ",p[j].itime2);
		printf("%s ",p[j].otime2);
		printf("%s ",p[j].itime3);
		printf("%s ",p[j].otime3);
		printf("%s\n",p[j].workinghrs);
	}

}


