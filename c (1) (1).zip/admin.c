#include "headers.h"
STU * Addtolist(STU *);
STU* Editlist(STU *);
STU*  Deletelist(STU *);
extern int i;
int mi=0;
STU *readmasterfile()
{
	STU *sp=NULL;
	FILE *fp;
	fp=fopen("mastercopy.csv","r");
	if(fp==NULL)
	{
		printf("File not Exists\n");
		exit(0);
	}
	char ch[256],cnt=0;	
	fgets(ch,256,fp);//for reading header file
	while(fgets(ch,256,fp))
	{
		sp=realloc(sp,(mi+1)*sizeof(STU));
		char *p=ch;
		p=strtok(p,",");
		strcpy(sp[mi].id,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[mi].name,p);
		p=NULL;
                p=strtok(p,",");
                strcpy(sp[mi].date,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[mi].status,p);	
		p=NULL;
		p=strtok(p,",");
		sp[mi].count=atoi(p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[mi].itime1,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[mi].otime1,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[mi].itime2,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[mi].otime2,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[mi].itime3,p);
		p=NULL;
		p=strtok(p,",");
		strcpy(sp[mi].otime3,p);
		p=NULL;
		p=strtok(p,",");
		strncpy(sp[mi].workinghrs,p,strlen(p)-1);
		mi++;
	}
	fclose(fp);
	return sp;
}
void writetomasterfile(STU *p)
{
	FILE *fp;
	fp=fopen("mastercopy.csv","r+");
	char ch[256],c[3];
	fgets(ch,256,fp);
	memset(ch,'\0',256);
	for(int j=0;j<mi;j++)
	{
		strcat(ch,p[j].id);
		strcat(ch,",");
		strcat(ch,p[j].name);
		strcat(ch,",");
		strcat(ch,p[j].date);
		strcat(ch,",");
		strcat(ch,p[j].status);
		strcat(ch,",");
		c[0]=p[j].count+48;
		c[1]='\0';
		strcat(ch,c);
		strcat(ch,",");
		strcat(ch,p[j].itime1);
		strcat(ch,",");
		strcat(ch,p[j].otime1);
		strcat(ch,",");
		strcat(ch,p[j].itime2);
		strcat(ch,",");
		strcat(ch,p[j].otime2);
		strcat(ch,",");
		strcat(ch,p[j].itime3);
		strcat(ch,",");
		strcat(ch,p[j].otime3);
		strcat(ch,",");
		strcat(ch,p[j].workinghrs);
		strcat(ch,"\n");
		fputs(ch,fp);
		memset(ch,'\0',256);
	}
	fclose(fp);
}
void adminmenu(void)
{
	STU *p;
	p=readmasterfile();
	char choice;
	while(1)
	{
		printf("1.ADD 2.EDIT 3.Delete 4.Print 5.Exit\n");
		__fpurge(stdin);
		scanf("%c",&choice);
		switch(choice)
		{
			case '1':p=Addtolist(p);
				 break;
			case '2':p=Editlist(p);
				 break;
			case '3':p=Deletelist(p);
				 break;
			case '4':printfile(p,2);
				 break;
			case '5':writetomasterfile(p);
				 return;
		}
	}
}

STU *Addtolist(STU *p)
{
	STU r;
	printf("Enter the ID\n");
	scanf("%s",r.id);
	printf("Enter the Name\n");
	scanf("%s",r.name);
	p=realloc(p,(mi+1)*sizeof(STU));
	strcpy(p[mi].id,r.id);
	strcpy(p[mi].name,r.name);
	strcpy(p[mi].status,"O");
	strcpy(p[mi].date,"00-00-0000");
	p[mi].count=0;
	strcpy(p[mi].itime1,"00:00");
	strcpy(p[mi].itime2,"00:00");
	strcpy(p[mi].itime3,"00:00");
	strcpy(p[mi].otime1,"00:00");
	strcpy(p[mi].otime2,"00:00");
	strcpy(p[mi].otime3,"00:00");
	strcpy(p[mi].workinghrs,"00:00");
	mi++;
	printf("Added to the List Successfully\n");
	return p;
}
STU *Editlist(STU *p)
{
	STU r;
	int a;
	m:printf("Enter the ID\n");
	scanf("%s",r.id);
	a=checkid(p,r.id,2);
	if(a==-1)
	{
		printf("Invalid ID\n");
		goto m;
	}
	printf("Enter the Name\n");
	scanf("%s",r.name);
	strcpy(p[a].name,r.name);
	printf("Edited Sucessfully\n");
	return p;
}
STU *Deletelist(STU *p)
{
	STU r;
	int a;
	a:printf("Enter the ID\n");
	scanf("%s",r.id);
	a=checkid(p,r.id,2);
	printf("%d\n",a);
	if(a==-1)
	{
		printf("Invalid ID\n");
		goto a;
	}
	memmove(p+a,p+a+1,(mi-a-1)*sizeof(STU));
	mi--;
	p=realloc(p,mi*sizeof(STU));
	printf("Deleted Sucessfully\n");
	return p;
}
	


		


