#include "headers.h"
extern int i;
extern int pcount;
int timetominutes(char *time)
{
	int hrs,mins;

	sscanf(time,"%d:%d",&hrs,&mins);
	return hrs*60+mins;
}
char * minutestotime(int minutes)
{
	static char p[20];
	int hrs=minutes/60;
	int mins=minutes%60;
	sprintf(p,"%02d:%02d",hrs,mins);
	return p;
}
int checktime(char *in,char *out)
{
	int itime=timetominutes(in);
	int otime=timetominutes(out);
	if(otime>itime)
	{
		return 1;
	}
	return 0;
}
char *addtime(char *i,char *o, char *w)
{
	int totalwork=timetominutes(w);
	int itime=timetominutes(i);
	int otime=timetominutes(o);
	totalwork=totalwork+(otime-itime);
	w=minutestotime(totalwork);
	return w;
}
STU * user(char *p,STU *sp)
{
	int j,flag=0,n;
	char *id,*time,*q;
	id=strtok(p," ");
	p=NULL;
	time=strtok(p,"$");
	for(j=0;j<i;j++)
	{
		if(strcmp(id,sp[j].id)==0)
		{
			flag=1;
			if(sp[j].status[0]=='O')
			{
				sp[j].count++;
				sp[j].status[0]='I';
				if(sp[j].count==1)
				{
					strcpy(sp[j].itime1,time);
					pcount++;
					break;
				}
				else if(sp[j].count==2)
				{
					n=checktime(sp[i].otime1,time);
					if(n==1)
					strcpy(sp[j].itime2,time);
					break;
				}
				else if(sp[j].count==3)
				{
					n=checktime(sp[i].otime2,time);
					if(n==1)
						strcpy(sp[j].itime3,time);
					break;
				}
				else
				{
					writetocomport('2');
					return sp;
				}
			}
			else if(sp[j].status[0]=='I')
			{
				if(sp[j].count==1)
				{
					n=checktime(sp[j].itime1,time);
					if(n==1)
					{
					  strcpy(sp[j].otime1,time);
					  q=addtime(sp[j].itime1,sp[j].otime1,sp[j].workinghrs);
					  strcpy(sp[j].workinghrs,q);
				          sp[j].status[0]='O';
				 	  break;
					}
				}
				else if(sp[j].count==2)
				{
					
					n=checktime(sp[j].itime2,time);
					if(n==1)
					{
					  strcpy(sp[j].otime2,time);
					  q=addtime(sp[j].itime2,sp[j].otime2,sp[j].workinghrs);
					  strcpy(sp[j].workinghrs,q);
				          sp[j].status[0]='O';
				 	  break;
					}
				}
				else if(sp[j].count==3)
				{

					n=checktime(sp[j].itime3,time);
					if(n==1)
					{
					  strcpy(sp[j].otime3,time);
					  q=addtime(sp[j].itime3,sp[j].otime3,sp[j].workinghrs);
					  strcpy(sp[j].workinghrs,q);
				          sp[j].status[0]='O';
				 	  break;
					}
				}
				else
				{
					writetocomport('2');
					return sp;
				}
			}
		}
	}
	if(flag)
	{
		writetocomport('1');
	}
	else
	{
		writetocomport('3');
	}
	return sp;
}
