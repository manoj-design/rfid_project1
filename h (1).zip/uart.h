
#include "typedef.h"
void InitUART(void);
//UART 0 functions
void U0_Tx_Char(u8 byte);
u8 U0_Rx_Char(void);
void U0_Tx_Str(s8 *s);
void U0_Rx_Str(s8 *);
//UART 1 Functions
void U1_Tx_Char(u8 byte);
s8 U1_Rx_Char(void);
void U1_Tx_Str(s8 *s);
void U1_Rx_Str(s8 *);
void UART_send(void);	


void ENABLE_UART_INT(void);
void DISABLE_UART_INT(void);
