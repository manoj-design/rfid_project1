#include "typedef.h"
void WriteLCD(u8 byte);
void cmdLCD(u8 cmd);
void charLCD(u8 asciiVal);
void InitLCD(void);
void strLCD(s8 *s);
void U32LCD(u32 n);
void S32LCD(s32 n);
void F32LCD(f32 fNum,u32 nDP);
void BuildCGRAM(int);
