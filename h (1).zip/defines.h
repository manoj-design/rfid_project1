//defines.h
#define RWBIT(WORD,DBIT,SBIT) \
        WORD=((WORD&~(1<<DBIT))| \
	           (((WORD>>SBIT)&1)<<DBIT))  	

#define RWBIT2(DWORD,DBIT,SWORD,SBIT) \
        DWORD=((DWORD&~(1<<DBIT))| \
	           (((SWORD>>SBIT)&1)<<DBIT))  	

#define SBIT(WORD,BIT) (WORD|=1<<BIT)
#define CBIT(WORD,BIT) (WORD&=~(1<<BIT))
#define TBIT(WORD,BIT) (WORD^=1<<BIT)
#define WBIT(WORD,BIT,BITLEVEL) \
        WORD=((WORD&~(1<<BIT))|(BITLEVEL<<BIT))
#define RBIT(WORD,BIT) ((WORD>>BIT)&1)

#define WNIBBLE(WORD,STARTBIT,NIBVAL) \
        WORD=((WORD&~(15<<STARTBIT))| \
				      (NIBVAL<<STARTBIT))
#define RNIBBLE(WORD,STARTBIT) ((WORD>>STARTBIT)&15)

#define WBYTE(WORD,STARTBIT,BYTE) (WORD=((WORD&~(255<<STARTBIT))|(BYTE<<STARTBIT)))
