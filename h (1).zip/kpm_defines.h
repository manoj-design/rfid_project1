//kpm_defines.h
#define ROW0 24//P1.16
#define ROW1 25//P1.17
#define ROW2 26//P1.18
#define ROW3 27//P1.19
#define COL0 28//P1.20
#define COL1 29//P1.21
#define COL2 30//P1.22
#define COL3 31//P1.23
