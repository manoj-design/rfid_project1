void delay_us(unsigned int dlyus);
void delay_ms(unsigned int dlyms);
void delay_s(unsigned int dlys);
