//spi_eeprom_test.c

#include "typedef.h"

void Init_SPI(void);

u8 spi(u8 sByte);
void WriteEnable(void);

void WriteDisable(void);

unsigned char spi_Read(void);
void spi_eeprom_bytewrite(u16 wBuffAddr,u8 wByte);
u8 spi_eeprom_byteread(u16 rBuffAddr);
void spi_eeprom_pagewrite(u16 wBuffAddr,s8 *p,int );
void spi_eeprom_sequentialread(u16 rBuffAddr,s8 *p,int nbytes);
