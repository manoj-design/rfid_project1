#ifndef _KPM_
#define _KPM_
#include "typedef.h"
u32 ColScan(void);
u32 RowCheck(void);
u32 ColCheck(void);
void InitKPM(void);
u32 KeyScan(void);
u32 readValue(void);
int checkPassword(void);
void setPassword(void);
#endif
