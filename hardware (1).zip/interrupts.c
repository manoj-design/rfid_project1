//eint0_eint1_test.c
#include <LPC21xx.h>
#include "LCD.h"
#include "delay.h"
#include "kpm.h"
#include "RTC.h"
#include "uart.h"
#include "spi.h"
#include<string.h>
#define EINT1_PIN 3       //@p0.3
#define EINT1_VIC_CHNO 15
#define EINT1_LED 2       //@p0.2
 

extern s8 admin[10];
extern s8 password[10];
extern s8 extint;
void menu(void)
{
	
char flag=1,k,p[20];
	cmdLCD(0x01);
	  while(1)
	  {	
		if(flag==1)
		{
			
			cmdLCD(0x80);
			strLCD("1.Change ID");
			cmdLCD(0x8D);
			strLCD("A-");
			BuildCGRAM(1);
			cmdLCD(0x8f);
			charLCD(0x00);
			cmdLCD(0xc0);
			strLCD("2.View Present");
			cmdLCD(0xcD);
			strLCD("B-");
			BuildCGRAM(2);
			cmdLCD(0xcf);
			charLCD(0x01);
			k=KeyScan();
			if(k=='A')
			{
				flag=2;
				cmdLCD(0x01);
			}
			else if(k=='B')
			{
				flag=1;
				cmdLCD(0x01);
			}
			else if(k=='1')
			{
				cmdLCD(0x01);
				delay_ms(10);
				cmdLCD(0x80);
				strLCD("Enter Password");
				if(checkPassword())
				{
					DISABLE_UART_INT();
					cmdLCD(0x01);
					cmdLCD(0x80);
					strLCD("PLACE CARD");
					U1_Rx_Str(p);
					memset(admin,'\0',10);
					strcpy(admin,p);
					spi_eeprom_pagewrite(0x0021,admin,8);
					cmdLCD(0xc0);
					strLCD(admin);
					ENABLE_UART_INT();
				}
				delay_ms(300);
				cmdLCD(0x01);
			}
			else if(k=='2')
			{
				cmdLCD(0x01);
				U0_Tx_Str("P$");
				U0_Rx_Str(p);
				cmdLCD(0x01);
				strLCD("Total: ");
				strLCD(p);
				cmdLCD(0x01);
				delay_ms(100);
			} 
			else if(k=='*')
			{
				cmdLCD(0x01);
				break;
			}
			else
			{
				cmdLCD(0x01);
				delay_ms(100);
				cmdLCD(0x80);
				strLCD("Invalid Key");
				delay_ms(100);
				cmdLCD(0x01);
			}
		}
		else if(flag==2)
		{
			cmdLCD(0x80);
			strLCD("3.Change PSD");
			cmdLCD(0x8D);
			strLCD("A-");
			BuildCGRAM(1);
			cmdLCD(0x8f);
			charLCD(0x00);
			cmdLCD(0xc0);
			strLCD("4.Exit");
			cmdLCD(0xcD);
			strLCD("B-");
			BuildCGRAM(2);
			cmdLCD(0xcf);
			charLCD(0x01);
			k=KeyScan();
			if(k=='A')
			{
				flag=1;
				cmdLCD(0x01);
			}
			else if(k=='3')
			{
				cmdLCD(0x01);
				cmdLCD(0x80);
				strLCD("Enter Password");
				if(checkPassword())
				{
					setPassword();
				}
				cmdLCD(0x01);
			}
			else if(k=='4')
			{
				cmdLCD(0x01);
				break;
			}
			else if(k=='B')
			{
				flag=1;
				cmdLCD(0x01);
			}
			else if(k=='*')
			{
				cmdLCD(0x01);
				break;
			}
			else
			{
				cmdLCD(0x01);
				cmdLCD(0x80);
				strLCD("Invalid Key");
				delay_ms(300);
				cmdLCD(0x01);
			}
		}
			
		while(ColScan()==0);
	}
} 
void eint1_isr(void) __irq
{

	cmdLCD(0x01);
	delay_ms(10);
	extint=1;
	EXTINT=1<<1;
	VICVectAddr=0;
}
void Enable_INTs(void)
{
	PINSEL0|=0x20000000;
	VICIntEnable=1<<EINT1_VIC_CHNO;
	VICVectCntl1=(1<<5)|EINT1_VIC_CHNO;
	VICVectAddr1=(int)eint1_isr;

}
