#include "LCD.h"
#include "delay.h"
#include "kpm.h"
#include "RTC.h"
#include "uart.h"
#include "spi.h"
#include "interrupts.h"
#include <string.h>
s8 admin[15],password[10],extint=0;
int main()
{    
	InitUART();
	Init_SPI();
	U1_Rx_Str(admin);
	U1_Tx_Str(admin);
    ENABLE_UART_INT();

	Enable_INTs();
	InitKPM();
	InitLCD();
	RTC_Init();
	sync_date_time();
	cmdLCD(0x83);
	strLCD("WELCOME");
	delay_ms(1000);
	cmdLCD(0x01);
	spi_eeprom_pagewrite(0x0021,"12543380",8);
	memset(admin,'\0',10);
	spi_eeprom_sequentialread(0x0021,admin,8);
	//U0_Tx_Str(admin);
	spi_eeprom_pagewrite(0x0051,"1234",4);
	memset(password,'\0',10);
	spi_eeprom_sequentialread(0x0051,password,4);
//	U0_Tx_Char(' ');
	//U0_Tx_Str(password);
	while(1)
	{
		cmdLCD(0x83);
		strLCD("PLACE CARD");
		cmdLCD(0xC0);
        strLCD(Get_Time());
        strLCD("   ");
        strLCD(Get_Date());
		if(extint==1)
		{
			menu();
			extint=0;
		}
	}		
}
