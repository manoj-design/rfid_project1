//kpm.c
#include <LPC21xx.h>
#include "typedef.h"
#include "defines.h"
#include "delay.h"
#include "kpm_defines.h"
#include "LCD.h"
#include "SPI.h"
#include <string.h>

u8 kpmLUT[4][4]=
{
	{'1','2','3','A'},
	{'4','5','6','B'},
	{'7','8','9','C'},
	{'*','0','#','D'}
};
extern s8 password[10];
u32 ColScan(void)
{
	return (RNIBBLE(IOPIN1,COL0)<15) ? 0 : 1;
}

u32 RowCheck(void)
{
	u32 r;
	for(r=0;r<=3;r++)
	{
		//grounding row 0 to 3 iteratively
		WNIBBLE(IOPIN1,ROW0,~(1<<r));
		//check wrt row grounded if cols is other than
		//all ones
		if(ColScan()==0)
			break ;
	}
	//re-initialize all rows to ground
	WNIBBLE(IOPIN1,ROW0,0);
	return r;
}	

u32 ColCheck(void)
{
	u32 c;
	for(c=0;c<=3;c++)
	{
		if(RBIT(IOPIN1,COL0+c)==0)
			break;
	}
	return c;
}

void InitKPM(void)
{ 
	IODIR1|=15<<ROW0;
}	
		
u8 KeyScan(void)
{
	u32 r,c;
	//wait to detect any key press
	while(ColScan());
	//Identify row in which key was pressed
	r=RowCheck();
	//Identify col in which key was pressed
	c=ColCheck();
	//extract key value from LUT
	return kpmLUT[r][c];
}
u32 myatoi(s8* p)
{
	u32 a=0;
	while(*p)
	{
		a=a*10+*p-48;
		p++;
	}
	return a;
}
		
u32 readValue(void)
{
	s8 a[10],k=0,i=0;
	u32 r;
	u8 j=0xc0;
	cmdLCD(j);
	strLCD("                ");
	while(1)
	{
		while(ColScan()==0);
		k=KeyScan();
		if(k>='0'&&k<='9')
		{
			a[i++]=k;
			cmdLCD(j);
			charLCD(k);
			j++;
		}
		else if(k=='D')
		{
			break;
		}
		else if(k=='C')
		{
			if(j==0)
			{  
				continue;
			}
			i--;
			j--;
			cmdLCD(j);
			charLCD(' ');
		}
		else
		{
			cmdLCD(0xc0);
			strLCD("Invalid Key");
			delay_ms(1000);
			cmdLCD(0xc0);
			strLCD("                ");
			cmdLCD(0xc0);
			strLCD("Re-Enter");
			delay_ms(300);
			cmdLCD(0xc0);
			strLCD("                ");
			i=0;
			j=0xc0;
		}
	
	}
	a[i]='\0';
	r=myatoi(a);
	return r;
}
int checkPassword(void)
{
	s8 k,a[10],i=0,j=0xc0;
	while(1)
	{
		while(ColScan()==0);
		k=KeyScan();
		if(k>='0'&&k<='9')
		{
			a[i++]=k;
			cmdLCD(j);
			charLCD(k);
			delay_ms(300);
			cmdLCD(j);
			charLCD('*');
			j++;
		}
		else if(k=='D')
		{
			break;
		}
		else if(k=='C')
		{
			if(j==0)
			{  
				continue;
			}
			i--;
			j--;
			cmdLCD(j);
			charLCD(' ');
		}
		else if(k=='*')
		{
			return;
		}
	}
	a[i]='\0';
	if((strcmp(password,a))==0)
	{
		return 1;
	}
	else
	{
		cmdLCD(0xc0);
		strLCD("Wrong Password");
		delay_ms(500);
		cmdLCD(0xc0);
		strLCD("                ");
		return 0;
	}
	
}
void setPassword(void)
{
	s8 k,a[10],b[10],i,j;
	m:i=0;
	j=0xc0;
	cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("New Password");
	while(1)
	{
		while(ColScan()==0);
		k=KeyScan();
		if(k>='0'&&k<='9')
		{
			a[i++]=k;
			cmdLCD(j);
			charLCD(k);
			delay_ms(300);
			cmdLCD(j);
			charLCD('*');
			j++;
		}
		else if(k=='D')
		{
			break;
		}
		else if(k=='C')
		{
			if(j==0)
			{  
				continue;
			}
			i--;
			j--;
			cmdLCD(j);
			charLCD(' ');
		}
		else if(k=='*')
		{
			return;
		}
	}
	a[i]='\0';
	cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("Re-Enter PSWD");
	delay_ms(500);
	cmdLCD(0xc0);
	strLCD("                ");
	i=0;
	j=0xc0;
	while(1)
	{
		while(ColScan()==0);
		k=KeyScan();
		if(k>='0'&&k<='9')
		{
			b[i++]=k;
			cmdLCD(j);
			charLCD(k);
			delay_ms(300);
			cmdLCD(j);
			charLCD('*');
			j++;
		}
		else if(k=='D')
		{
			break;
		}
		else if(k=='C')
		{
			if(j==0)
			{  
				continue;
			}
			i--;
			j--;
			cmdLCD(j);
			charLCD(' ');
		}
	}
	b[i]='\0';
	if((strcmp(a,b))==0)
	{
		strcpy(password,a);
		spi_eeprom_pagewrite(0x0051,password,strlen(password));
		
	}
	else
	{
		cmdLCD(0x01);
		cmdLCD(0x80);
		strLCD("Invalid PSWD's");
		delay_ms(500);
		goto m;
	}
}

			
			
			
			
			
	
	
