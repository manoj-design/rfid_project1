
#include "typedef.h"
void RTC_Init(void);
void RTC_SetTime(u8 hours, u8 minutes, u8 seconds);
void RTC_SetDate(u8 , u8 , u16);
char * Get_Date(void);
char * Get_Time(void);
void sync_date_time(void);
