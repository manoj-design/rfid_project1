#include "LCD.h"
#include "delay.h"
#include "kpm.h"
#include "RTC.h"
#include "uart.h"
#include "spi.h"
#include "interrupts.h"
#include <string.h>
extern s8 admin[10];
extern s8 password[10];
extern s8 uart;
extern s8 extint;
int main()
{
		  char message[] = "PLACE CARD";  // Define the message to be scrolled
    int len = strlen(message);      // Get the length of the message
    int i, j;
	InitUART();
	Init_SPI();
  ENABLE_UART_INT();
	Enable_INTs();
	InitKPM();
	InitLCD();
	RTC_Init();
	//sync_date_time();
	cmdLCD(0x83);
	strLCD("WELCOME");
	delay_ms(1000);
	cmdLCD(0x01);
	/*spi_eeprom_pagewrite(0x0021,"12543380",8);
	memset(admin,'\0',10);
	spi_eeprom_sequentialread(0x0021,admin,8);
	//admin[8]='\0';
	//U0_Tx_Str(admin);
	spi_eeprom_pagewrite(0x0051,"1234",4);
	memset(password,'\0',10);
	spi_eeprom_sequentialread(0x0051,password,4);
//	U0_Tx_Char(' ');
	//U0_Tx_Str(password);
	//password[8]='\0';*/
	while(1)
	{
        // Scroll the message in a circular motion
        for(i = 0; i <= 16; i++)
        {
            cmdLCD(0x80); // Set cursor at the beginning of the first line

            // Display the shifted message
            for(j = 0; j < 16; j++)
            {
                if((i + j) < len)
                    strLCD(&message[(i + j) % len]);  // Circular shift using modulo
                else
                    strLCD(" ");  // Fill the rest of the line with spaces
            }

            delay_ms(300);  // Delay for smoother scrolling effect

            cmdLCD(0x80);   // Clear the first line
            strLCD("                ");  // Clear the message

            // Display time and date on the second line
            cmdLCD(0xC0);
            strLCD(Get_Time());
            strLCD("   ");
            strLCD(Get_Date());
        }
		if(uart==1)
		{
			UART_send();
			uart=0;
		}
		if(extint==1)
		{
			menu();
			extint=0;
		}
	}		
}