#include <LPC21xx.h>
#include "typedef.h"
#include "delay.h"

#define LCD_DATA 16 //p1.17
#define LCD_EN 17	//p0.17
#define LCD_RS 16 //p0.16
u8 p2[8]={0x04,0x0e,0x1f,0x0e,0x0e,0x0e,0x0e,0x0e};
u8 p1[8]={0x0e,0x0e,0x0e,0x0e,0x1f,0x0e,0x04,0x00};
void WriteLCD(unsigned char byte)
{
	IOPIN1=(IOPIN1&~(255<<LCD_DATA))|(byte<<LCD_DATA);
	IOSET0=1<<LCD_EN;
	delay_ms(1);
	IOCLR0=1<<LCD_EN;
	delay_ms(2);
}

void cmdLCD(u8 cmd)
{
	IOCLR0=1<<LCD_RS;
	WriteLCD(cmd);
}

void charLCD(u8 asciiVal)
{
  IOSET0=1<<LCD_RS;
	WriteLCD(asciiVal);
}

void InitLCD(void)
{
	IODIR1|=(0xFF<<LCD_DATA);
	IODIR0|=(1<<LCD_RS)|(1<<LCD_EN);
	delay_ms(15);
	cmdLCD(0x30);
	delay_ms(5);
	cmdLCD(0x30);
	delay_us(100);
	cmdLCD(0x30);
	cmdLCD(0x38);
	cmdLCD(0x0c);
	cmdLCD(0x01);
	cmdLCD(0x06);
}

void strLCD(s8 *s)
{
	while(*s)
		charLCD(*s++);
}

void U32LCD(u32 n)
{
	u8 a[10];
	s32 i=0;
	if(n==0)
		charLCD('0');
	else
	{
		while(n>0)
		{
			a[i++]=(n%10)+48;
			n/=10;
		}
		for(--i;i>=0;i--)
		   charLCD(a[i]);
	}
}	
void S32LCD(s32 n)
{
	if(n<0)
	{
		charLCD('-');
		n=-n;
	}
  U32LCD(n);	
}
void F32LCD(f32 fNum,u32 nDP)
{
	s32 num,i;
	num=fNum;
	if(num<0)
	{
		charLCD('-');
		num=-num;
	}
	U32LCD(num);
	charLCD('.');
	for(i=0;i<nDP;i++)
	{
		fNum=(fNum-num)*10;
		num=fNum;
		charLCD(num+48);
	}
}
void BuildCGRAM(int n)
{
	u8 j;
	 //goto cgram start area
	
	if(n==1)
	{
		cmdLCD(0x40);
		for(j=0;j<8;j++)
		{
      charLCD(p1[j]);
    }
	}
	else
	{
		cmdLCD(0x48);		
		for(j=0;j<8;j++)
		{
      charLCD(p2[j]);
    }
	}
		
}


