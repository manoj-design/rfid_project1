#include <LPC21xx.h>
#include "typedef.h"
#include "delay.h"
#include "lcd_defines.h"


void WriteLCD(unsigned char byte)
{
	//place data onto data pins(d7 to d0)
	IOPIN1=(IOPIN1&~(255<<LCD_DATA))|(byte<<LCD_DATA);
	IOSET0=1<<LCD_EN;
	delay_ms(1);
	IOCLR0=1<<LCD_EN;
	delay_ms(2);
}

void cmdLCD(u8 cmd)
{
	//sel cmd reg
	IOCLR0=1<<LCD_RS;
	//write to cmd reg
	WriteLCD(cmd);
}

void charLCD(u8 asciiVal)
{
	//sel data reg
	IOSET0=1<<LCD_RS;
	//write to ddram/cgram via data reg
	WriteLCD(asciiVal);
}

void InitLCD(void)
{
	//cfg d0-d7,rs,en as gpio out pins
	IODIR1|=(0xFF<<LCD_DATA);
	IODIR0|=(1<<LCD_RS)|(1<<LCD_EN);
	//power on/rst delay
	delay_ms(15);
	cmdLCD(0x30);
	delay_ms(5);
	cmdLCD(0x30);
	delay_us(100);
	cmdLCD(0x30);
	cmdLCD(MODE_8BIT_2LINE);
	cmdLCD(DSP_ON_CUR_OFF);
	cmdLCD(CLEAR_LCD);
	cmdLCD(SHIFT_CUR_RIGHT);
}

void strLCD(s8 *s)
{
	while(*s)
		charLCD(*s++);
}

void U32LCD(u32 n)
{
	u8 a[10];
	s32 i=0;
	if(n==0)
		charLCD('0');
	else
	{
		while(n>0)
		{
			a[i++]=(n%10)+48;
			n/=10;
		}
		for(--i;i>=0;i--)
		   charLCD(a[i]);
	}
}	
void S32LCD(s32 n)
{
	if(n<0)
	{
		charLCD('-');
		n=-n;
	}
  U32LCD(n);	
}
void F32LCD(f32 fNum,u32 nDP)
{
	s32 num,i;
	num=fNum;
	if(num<0)
	{
		charLCD('-');
		num=-num;
	}
	U32LCD(num);
	charLCD('.');
	for(i=0;i<nDP;i++)
	{
		fNum=(fNum-num)*10;
		num=fNum;
		charLCD(num+48);
	}
}


}

