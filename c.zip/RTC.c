#include <LPC21xx.h>
#include "typedef.h"
#include "kpm.h"
#include "LCD.h"
#include "delay.h"
#include "uart.h"
void RTC_Init(void) 
{
    PREINT = 0x000001C8; 
    PREFRAC = 0x000061C0; 
    CCR = 0x01;        
}

void RTC_SetTime(u8 hours, u8 minutes, u8 seconds)
{
    CCR = 0x02;           
    HOUR = hours;         
    MIN = minutes;        
    SEC = seconds;       
    CCR = 0x01;           
}
void RTC_SetDate(u8 day, u8 month, u16 year)
{
    CCR = 0x02;           
		DOM=day;
		MONTH=month;
		YEAR=year;
    CCR = 0x01;           
}
void read_date_time(s8*buff)
{
	u32 hrs,mins,sec,year,month,day;
	sscanf(buff,"%d-%d-%d %d:%d:%d",&year,&month,&day,&hrs,&mins,&sec);
	RTC_SetTime(hrs,mins,sec);
	RTC_SetDate(day,month,year);
}
void sync_date_time(void)
{
	char p[20];
	U0_Tx_Str("D$");
	U0_Rx_Str(p);
	read_date_time(p);
}

char * Get_Time(void)
{
					s8 time[10],*ptr;
					u8 hrs,min,sec;
					hrs=HOUR;
					min=MIN;
					sec=SEC;
					time[0]=(hrs/10+'0');
					time[1]=(hrs%10+'0');
					time[2]=(':');
					time[3]=(min/10+'0');
					time[4]=(min%10+'0');
					/*time[5]=(':');
				  time[6]=(sec/10+'0');
					time[7]=(sec%10+'0');*/
					time[5]='\0';
					ptr=time;
					return ptr;
}
char * Get_Date(void)
{
					s8 Date[12],*ptr;
					u8 day,month;
					u16 year;
					month=MONTH;
					day=DOM;
					year=YEAR;
					Date[0]=(day/10+'0');
					Date[1]=(day%10+'0');
					Date[2]=('-');
					Date[3]=(month/10+'0');
					Date[4]=(month%10+'0');
					Date[5]=('-');
				  /*Date[6]=(year/1000+'0');
					Date[7]=((year/100)%10+'0');*/
					Date[6]=((year/10)%10+'0');
					Date[7]=(year%10+'0');
					Date[8]='\0';
					ptr=Date;
					return ptr;
}
#include <stdbool.h>

bool IsLeapYear(u8 year) {
    return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
}

u8 GetDaysInMonth(u8 month, u8 year) {
    switch (month) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            return 31;
        case 4: case 6: case 9: case 11:
            return 30;
        case 2:
            if (IsLeapYear(year)) {
                return 29;
            } else {
                return 28;
            }
        default:
            return 0;}
}

bool ValidateDate(u8 day, u8 month, u16 year)
{
    u8 maxDays = GetDaysInMonth(month, year);
    return (day >= 1 && day <= maxDays);
}


void Edit_Date(void)
{
	u8 day,month;
	u16 year;
	y:cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("Enter Year");
	year=readValue();
	if(year==0)
	{
		cmdLCD(0xc0);
		strLCD("Invalid Year");
		delay_ms(1000);
		goto y;
	}
	delay_ms(1000);
	m:cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("Enter Month");
	month=readValue();
	if(month<1||month>12)
	{
		cmdLCD(0xc0);
		strLCD("Invalid Month");
		delay_ms(1000);
		goto m;
	}
	delay_ms(1000);
	cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("Enter DOM");
	d:day=readValue();
	if(!(ValidateDate(day,month,year)))
	{
		cmdLCD(0xc0);
		strLCD("Invalid Date");
		delay_ms(1000);
		goto d;
	}
	cmdLCD(0x01);
	cmdLCD(0x80);
	RTC_SetDate(day,month,year);
	strLCD("Date Changed");
	cmdLCD(0xc0);
	strLCD("Sucessfully");
	delay_ms(1000);
	cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD(Get_Date());
	delay_ms(2000);
	cmdLCD(0x01);
	
}
void Edit_Time(void)
{
	char sec,min,hrs;
	s:cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("Enter Seconds");
	sec=readValue();
	if(sec>59)
	{
		strLCD("Invalid Secs");
		delay_ms(100);
		goto s;
		
	}
	mi:cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("Enter Mins");
	min=readValue();
	if(min>59)
	{
		strLCD("Invalid Minutes");
		delay_ms(100);
		goto mi;
	}
	cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("Enter Hour");
	h:hrs=readValue();
	if(hrs>23)
	{
		strLCD("Invalid Hours");
		delay_ms(100);
		goto h;
	}
	RTC_SetTime(hrs,min,sec);
	cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("Time Changed");
	cmdLCD(0xc0);
	strLCD("Sucessfully");
	delay_ms(1000);
	cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD(Get_Time());
}
