//uart.c
#include <LPC21xx.h>
#include "types.h"
#include "delay.h"
#include "uart_defines.h"

void Init_UART0(void)
{
	//cfg p0.0 & p0.1 as txd0 & rxd0 for uart0
	PINSEL0|=0x00000005;
	//cfg uart0 for 8bits,no parity,1stop,(8N1)
	U0LCR=1<<DLAB_BIT|WORD_LEN_SEL_BITS;
	//cfg baud rate
	U0DLM=DIVISOR>>8;
	U0DLL=DIVISOR;
	//disable DLAB bit
	U0LCR&=~(1<<DLAB_BIT);	
}

void U0_TxChar(u8 sByte)
{
	//place data for transmission into tx-buff
	U0THR=sByte;
	//wait until transmission completion status
	while(((U0LSR>>TEMT_BIT)&1)==0);
}

u8 U0_RxChar(void)
{
	//wait for reception status
	while(((U0LSR>>DR_BIT)&1)==0);
	//read & return recvd byte
	return U0RBR;
}

void U0_TxStr(s8 *s)
{
	while(*s)
		U0_TxChar(*s++);
}

void U0_TxU32(u32 n)
{
	u8 a[10];	s32 i=0;
	if(n==0)
		U0_TxChar('0');
	else
	{
		while(n>0)
		{
			a[i++]=(n%10)+48;
			n/=10;
		}
		for(--i;i>=0;i--)
		   U0_TxChar(a[i]);
	}
}	

void U0_TxS32(s32 n)
{
	if(n<0)
	{
		U0_TxChar('-');
		n=-n;
	}
  U0_TxU32(n);	
}

void U0_TxF32(f32 fNum,u32 nDP)
{
	s32 num,i;
	if(fNum<0)
	{
		U0_TxChar('-');
		fNum=-fNum;
	}
	num=fNum;
	U0_TxU32(num);
	U0_TxChar('.');
	for(i=0;i<nDP;i++)
	{
		fNum=(fNum-num)*10;
		num=fNum;
		U0_TxChar(num+48);
	}
}

s8 * U0_RxStr(void)
{
	 s32 i=0;
	 static s8 rxStr[100],t;
	 while(1)
	 {
		 t=rxStr[i]=U0_RxChar();
		 U0_TxChar(t);
		 if((t=='\n')||(t=='\r'))
		 {
			 rxStr[i]='\0';
			 break;
		 }	
     i++;
   } 	
	 U0_TxStr("\n\r");
   return rxStr;	 
 }	
